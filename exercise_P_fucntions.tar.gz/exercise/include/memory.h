#pragma once

#include <stdint.h>
#include <stdlib.h>

#define MEMORY_SIZE  0x10000

class Memory
{
private:
	uint8_t* _mem;
public:
	Memory();
	uint32_t get(uint32_t address);
	void set(uint32_t address, uint32_t value);
};