#pragma once

#include "program.h"
#include "memory.h"
#include "instruction.h"
#include <memory>

typedef void (*f_ptr)(Instruction* instruction, Memory *memory, uint32_t* registers);

class Interpreter
{
	uint32_t _registers[16];
	f_ptr _executeMap[16] ;

public:
	void runProgram(Program *program, Memory *memory);
};