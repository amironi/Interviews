#pragma once

#include "instruction.h"
#include "memory.h"
#include <vector>

class Program
{
private:
	std::vector<Instruction*> _instructions;
public:
	Program();
	bool isLastInstruction(uint32_t index);
	Instruction* getInstruction(uint32_t index);
	bool expectedResult(Memory *mem);	
};