#include "../include/memory.h"

Memory::Memory()
{
	_mem = (uint8_t *) calloc(0x10000, 1);	
}

uint32_t Memory::get(uint32_t address)
{
    if (address >= MEMORY_SIZE)
    {
        throw "Bad Access - wrong address accessed";
    }

	uint32_t value = _mem[address + 3] << 24 | _mem[address + 2] << 16 | _mem[address + 1] << 8 | _mem[address + 0];
    return value;
}

void Memory::set(uint32_t address, uint32_t value)
{
    if (address >= MEMORY_SIZE)
    {
        throw "Bad Access - wrong address accessed";
    }

    _mem[address] = value;
    _mem[address + 1] = value >> 8;
    _mem[address + 2] = value >> 16;
    _mem[address + 3] = value >> 24;
}