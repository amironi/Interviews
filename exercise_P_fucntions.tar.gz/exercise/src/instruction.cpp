#include "../include/instruction.h"

Instruction::Instruction(InstructionType type) : _type(type)
{

}

InstructionType Instruction::type()
{
	return _type;
}

uint32_t Instruction::numOfOperands()
{
	return _operands.size();
}

Operand Instruction::getOperand(uint32_t index)
{
	return _operands[index];
}

void Instruction::addOperand(Operand operand)
{
	_operands.push_back(operand);
}

