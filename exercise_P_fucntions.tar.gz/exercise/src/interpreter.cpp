#include "../include/interpreter.h"
#include <iostream>
#include <string>

using namespace std;

uint32_t getOperand(Operand operand, uint32_t* registers){

    uint32_t v = operand.value;
    
    if( operand.type == Register ) 
        v = registers[v];
    return v;
}


void ExecuteMov(Instruction* instruction, Memory *memory, uint32_t* registers )
{
    registers[instruction->getOperand(0).value] = 
        getOperand(instruction->getOperand(1), registers);
}

void ExecuteLdr(Instruction* instruction, Memory *memory, uint32_t* registers )
{
    registers[instruction->getOperand(0).value] = 
        memory->get(getOperand(instruction->getOperand(1), registers));
}

void ExecuteStr(Instruction* instruction, Memory *memory, uint32_t* registers )
{
    memory->set(
        getOperand(instruction->getOperand(1), registers), 
        registers[instruction->getOperand(0).value]);
}

void ExecuteB(Instruction* instruction, Memory *memory, uint32_t* registers )
{
    registers[15] = getOperand(instruction->getOperand(0), registers);
}

void ExecuteBcon(Instruction* instruction, Memory *memory, uint32_t* registers )
{
    if( getOperand(instruction->getOperand(0), registers)  == 1 )
        registers[15] = getOperand(instruction->getOperand(1), registers);
}


void ExecuteGTE(Instruction* instruction, Memory *memory, uint32_t* registers )
{
    registers[instruction->getOperand(0).value] = 
        getOperand(instruction->getOperand(1), registers) >=
        getOperand(instruction->getOperand(2), registers);
}


void ExecuteAdd(Instruction* instruction, Memory *memory, uint32_t* registers )
{
    registers[instruction->getOperand(0).value] = 
        getOperand(instruction->getOperand(1), registers) + 
        getOperand(instruction->getOperand(2), registers);
}


void print(Operand operand)
{
    if( operand.type == Register )  
        cout << "R";    
        
    cout << operand.value;
    }

void printProgram(Program *prog, Memory *memory)
{

    std::string  _str[16];

    _str[MOV] = "MOV";
    _str[LDR] = "LDR";
    _str[STR] = "STR";
    _str[B] = "B";
    _str[BCond] = "BCond";
    _str[GTE] = "GTE";
    _str[ADD] = "ADD";
    
    int r = 0;
    
    while(false == prog->isLastInstruction(r))
    {
        Instruction* instruction = prog->getInstruction(r++);

        cout << _str[instruction->type()] << " "; 

        print(instruction->getOperand(0));

        for(int i = 1 ; i < instruction->numOfOperands() ; ++i )
        {
            cout << ", ";
            print(instruction->getOperand(i));    
        }

        cout << endl;
    }
}

void Interpreter::runProgram(Program *prog, Memory *memory)
{
    printProgram(prog, memory);

    _executeMap[MOV] = &ExecuteMov;
    _executeMap[LDR] = &ExecuteLdr;
    _executeMap[STR] = &ExecuteStr;
    _executeMap[B] = &ExecuteB;
    _executeMap[BCond] = &ExecuteBcon;
    _executeMap[GTE] = &ExecuteGTE;
    _executeMap[ADD] = &ExecuteAdd;
    
    _registers[15] = 0;

    while(false == prog->isLastInstruction(_registers[15]))
    {
        Instruction* instruction = prog->getInstruction(_registers[15]++);

        (*_executeMap[instruction->type()])( instruction, memory, _registers);
   }
    
}