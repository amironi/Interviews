////////////////////////////////////////////////////////////
//
//          Component.h
//
////////////////////////////////////////////////////////////

#pragma once
#include "Interface.h"

class Component : public IAAA,
                  public IBBB,
                  public ICCC
{
public:
	virtual HRESULT __stdcall QueryInterface(const IID& id, void** p);
	virtual ULONG   __stdcall AddRef();
	virtual ULONG   __stdcall Release();

	virtual HRESULT STDMETHODCALLTYPE Test1( long value );

	virtual HRESULT STDMETHODCALLTYPE Test2( struct date __RPC_FAR *theDate );
 
	virtual HRESULT STDMETHODCALLTYPE get_Test3( long __RPC_FAR *value );
	virtual HRESULT STDMETHODCALLTYPE put_Test3( long value );
	virtual HRESULT STDMETHODCALLTYPE Test4( unsigned char __RPC_FAR *message );
        

	virtual HRESULT STDMETHODCALLTYPE Test5( struct date __RPC_FAR **theDate );

	virtual HRESULT STDMETHODCALLTYPE Test6( long __RPC_FAR array[],
																					 long size,
																					 long first,
																					 long length);
 
    
	Component() : count(0), property(0) {}

private:
	int property;
	int count;
};


