#include <assert.h>
#include <comdef.h>
#include <iostream>
#import "../Errors/Errors.tlb"
using namespace ERRORSLib;
using namespace std;

HRESULT hr;


int main()
{
	CoInitialize(0);

	try
	{
		IServerPtr p( __uuidof(Server) );

		double result;
		double number = 100.00;

		while( true )
		{
			// loop until number goes negative and an exception is thrown
			result = p->SquareRoot( number );
			cout << "Square root of " << number << " = " << result << endl;
			number = number - 5.0;
		}
	}
	catch (const _com_error& e) 
	{
		LPOLESTR GUID_String;
		StringFromCLSID( e.GUID(), &GUID_String );
		
		bstr_t theDescription = e.Description();
		bstr_t theSource			= e.Source();
		bstr_t theGUID( GUID_String );
		bstr_t theError 			= e.ErrorMessage();

		bstr_t theMessage = "Description: " + theDescription + "\n"
											+ "Source:      " + theSource 		 + "\n"
											+ "GUID:        " + theGUID 			 + "\n"
											+ "Error:       " + theError;
		MessageBox(0, theMessage, "Throwing Errors", MB_OK);
	}

	CoUninitialize();
	return 0;
}