////////////////////////////////////////////////////////////
//
//			Name.cpp
//
////////////////////////////////////////////////////////////

#include <iostream>
#include "Name.h"
using namespace std;

class Name : public IConvert, 
						 public IGetSet, 
						 public IEncodeDecode
{
public:
	Name() : count(0) {}
	virtual void QueryInterface(const string&, void**);
	virtual int  AddRef();
	virtual int  Release();
	virtual void ToUpper();
	virtual void ToLower();
	virtual string Get();
	virtual void Set(const string&);
	virtual void Print();
	virtual void Encode();
	virtual void Decode();
private:
	string name;
	int 	 count;
};

/////

extern "C"
{
	__declspec(dllexport) void CreateInstance(void** ppObject)
	{
		Name* p = new Name;
		p->AddRef();
		*ppObject = reinterpret_cast<void*>(p);
		cout << "Object created" << endl;
	}
}

/////

void Name::QueryInterface(const string& theInterface, void** ppInterface)
{
	*ppInterface = 0; // prepare for failure

	if( theInterface == "IUnknown" )
	{
		*ppInterface = static_cast<IGetSet*>(this);
	}
	else if( theInterface == "IGetSet" )
	{
		*ppInterface = static_cast<IGetSet*>(this);
	}
	else if( theInterface == "IConvert" )
	{
		*ppInterface = static_cast<IConvert*>(this);
	}
	else if (theInterface == "IEncodeDecode") 
	{
		*ppInterface = static_cast<IEncodeDecode*>(this);
	}

	if( *ppInterface != 0 ) 
	{
		AddRef();
	}
}

int Name::AddRef()
{
		return ++count;
}

int Name::Release()
{
	count--;
	if(count == 0)
	{
		cout << "Object destroyed" << endl;
		delete this;
		return 0;
	}
	return count;
}

void Name::ToUpper()
{
	for(int i = 0; i < name.size(); i++)
	{
			name[i] = toupper(name[i]);
	}
}

void Name::ToLower()
{
	for(int i = 0; i < name.size(); i++)
	{
		name[i] = tolower(name[i]);
	}
}

string Name::Get()
{
	return name;
}

void Name::Set(const string& theName)
{
	name = theName;
}

void Name::Print()
{
	cout << Get() << endl;
}

void Name::Encode()
{
	for(int i = 0; i < name.size(); i++)
	{
		if( isalpha( name[i] ) )
		{
			switch( name[i] )
			{
				default:	name[i]++;		 break;
				case 'Z': name[i] = 'A'; break;
				case 'z': name[i] = 'a'; break;
			}
		}
	}
}

void Name::Decode()
{
	for(int i = 0; i < name.size(); i++)
	{
		if( isalpha( name[i] ) )
		{
			switch( name[i] )
			{
				default:	name[i]--;		 break;
				case 'A': name[i] = 'Z'; break;
				case 'a': name[i] = 'z'; break;
			}
		}
	}
}

