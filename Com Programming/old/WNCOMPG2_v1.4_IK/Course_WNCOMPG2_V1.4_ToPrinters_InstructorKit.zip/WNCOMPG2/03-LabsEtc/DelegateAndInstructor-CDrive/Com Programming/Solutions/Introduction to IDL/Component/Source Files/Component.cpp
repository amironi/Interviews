////////////////////////////////////////////////////////////
//
//	    Component.cpp
//
////////////////////////////////////////////////////////////

#include <stdio.h>
#include <windows.h>
#include "Component.h"
#include "ClassFactory.h"

HRESULT __stdcall Component::QueryInterface(REFIID id, void** p)
{
	*p = 0;     // prepare for failure

	if(id == IID_IUnknown) 
		*p = static_cast<IUnknown*>(static_cast<IAAA*>(this));
	if(id == IID_IAAA)     
		*p = static_cast<IAAA*>(this);
	if(id == IID_IBBB)     
		*p = static_cast<IBBB*>(this);
	if(id == IID_ICCC)     
		*p = static_cast<ICCC*>(this);

	if(*p == 0)
		return E_NOINTERFACE;
	else
	{
		AddRef();
		return S_OK;
	}
}

ULONG __stdcall Component::AddRef()
{
	return ++count;
}

ULONG __stdcall Component::Release()
{
	if(--count == 0)
	{
		delete this;
		classFactory.DecrementObjectCount();
		return 0;
	}

	return count;
}


HRESULT STDMETHODCALLTYPE Component::Test1( long value )
{
	char szTemp[30];
	_ltoa( value, szTemp, 10 );

	MessageBoxA( 0, szTemp, "Test1", MB_OK );

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Component::Test2( struct date __RPC_FAR *theDate )
{
	
	theDate->day = 31;
	theDate->month = 12;
	theDate->year = 1999; // or should it be 2000 - hmmm?

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Component::get_Test3( long __RPC_FAR *value )

{
	*value = property;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Component::put_Test3( long value )
{
	property = value;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Component::Test4( unsigned char __RPC_FAR *message )
{
	MessageBoxA( 0, (char *) message, "Test4", MB_OK );

	return S_OK;
}
      

HRESULT STDMETHODCALLTYPE Component::Test5( struct date __RPC_FAR **theDate )
{
	
	if( !(*theDate) )
	{
		*theDate = (date *) CoTaskMemAlloc( sizeof( date ) );

		if( !(*theDate) )
		{
			return E_OUTOFMEMORY;
		}
	}

	Test2( *theDate );

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Component::Test6( long __RPC_FAR array[],
																				 long size,
																				 long first,
																				 long length)
{

	for( int i = 0; i < size; ++i )
	{
		if( i >= first && i < first + length )
		{
			array[i] *= 2;
		}
	}

	return S_OK;
}