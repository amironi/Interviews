// DataTypes.cpp : Implementation of CDataTypesApp and DLL registration.

#include "stdafx.h"
#include "Data Types.h"
#include "DataTypes.h"
#include <comdef.h>

/////////////////////////////////////////////////////////////////////////////
//

STDMETHODIMP DataTypes::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISafeArray,
		&IID_IVariant,
		&IID_IBSTR,
	};

	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}
// OLECHAR
STDMETHODIMP DataTypes::CreateArray(SAFEARRAY** ppArray)
{
	*ppArray = SafeArrayCreateVector(VT_I4, 0, 5);
	long* data = 0;
	SafeArrayAccessData(*ppArray, reinterpret_cast<void**>(&data));

	for(int i = 0; i < 5; i++)
	{
		data[i] = i;
	}

	SafeArrayUnaccessData(*ppArray);
	return S_OK;
}

STDMETHODIMP DataTypes::DoubleArray(SAFEARRAY** ppArray)
{
	long* data = 0;
	HRESULT hr = SafeArrayAccessData(*ppArray, reinterpret_cast<void**>(&data));
	if(FAILED(hr)) 
		return hr;

	for(int i = 0; i < 5; i++)
	{
		data[i] = 2 * data[i];
	}

	SafeArrayUnaccessData(*ppArray);
	return S_OK;
}

STDMETHODIMP DataTypes::SumTheArray(SAFEARRAY** ppArray, long* pTotal)
{
	*pTotal = 0;
	long* data = 0;
	
	HRESULT hr = SafeArrayAccessData(*ppArray, reinterpret_cast<void**>(&data));
	
	if(FAILED(hr)) 
		return hr;

	for(int i = 0; i < 5; i++)
	{
		*pTotal += data[i];
	}

	SafeArrayUnaccessData(*ppArray);
	return S_OK;
}

STDMETHODIMP DataTypes::ExpandRectangle(VARIANT *pRectangle)
{
	
	if( pRectangle->vt != (VT_ARRAY|VT_VARIANT) )
	{
		return Error( "Wrong type of array", IID_IVariant, E_FAIL );
	}
	
	// rectangle stored as an array inside variant
	// so unpack array
	SAFEARRAY* p = pRectangle->parray;
	VARIANT* pData;
	
	HRESULT hr = SafeArrayAccessData(p, reinterpret_cast<void**>(&pData));

	// name each component
	VARIANT& top		= pData[0];
	VARIANT& left 	= pData[1];
	VARIANT& width	= pData[2];
	VARIANT& height = pData[3];

	// expand rectangle about its center by 20 pixels
	height.lVal += 20;
	width.lVal	+= 20;
	top.lVal		-= 10;
	left.lVal 	-= 10;
		
	// tidy up
	SafeArrayUnaccessData(p);

	return S_OK;
}

// choose which method to manipulate strings (CComBSTR, _bstr_t, BSTR)
#define USING_CComBSTR 1
#define USING_bstr_t	 2
#define USING_BSTR		 3
#define STRING_TYPE 	 USING_BSTR


STDMETHODIMP DataTypes::ToUpper(BSTR *pString)
{
#if STRING_TYPE == USING_CComBSTR

	CComBSTR s(*pString);
	SysFreeString(*pString);
	s.ToUpper();
	*pString = s.Copy();

#elif STRING_TYPE == USING_bstr_t

		_bstr_t s(*pString);
	SysFreeString(*pString);

		// get a pointer to the internal _bstr_t buffer
	wchar_t* pBuffer = (wchar_t*) s;

	for(unsigned i = 0; i < s.length(); i++)
	{
		pBuffer[i] = towupper(pBuffer[i]);
	}
		
	*pString = s; // copy string

#elif STRING_TYPE == USING_BSTR

		BSTR& s = *pString; 
	int length = SysStringLen(s);

	for(int i = 0; i < length; i++)
	{
			s[i] = towupper(s[i]);
	}

#endif
	return S_OK;
}

STDMETHODIMP DataTypes::ToLower(BSTR *pString)
{
#if STRING_TYPE == USING_CComBSTR

		CComBSTR s(*pString);
	SysFreeString(*pString);
	s.ToLower();
	*pString = s.Copy();

#elif STRING_TYPE == USING_bstr_t

		_bstr_t s(*pString);
		// get a pointer to the internal _bstr_t buffer
	wchar_t* pBuffer = (wchar_t*) s;

	for(unsigned i = 0; i < s.length(); i++)
	{
		pBuffer[i] = towlower(pBuffer[i]);
	}

#elif STRING_TYPE == USING_BSTR

		BSTR& s = *pString; 
	int length = SysStringLen(s);

	for(int i = 0; i < length; i++)
	{
			s[i] = towlower(s[i]);
	}

#endif
	return S_OK;
}
