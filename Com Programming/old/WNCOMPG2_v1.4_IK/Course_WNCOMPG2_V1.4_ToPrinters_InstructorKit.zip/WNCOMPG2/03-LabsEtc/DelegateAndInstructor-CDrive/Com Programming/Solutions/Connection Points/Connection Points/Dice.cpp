// Dice.cpp : Implementation of CDice
#include "stdafx.h"
#include "Connection Points.h"
#include "Dice.h"

/////////////////////////////////////////////////////////////////////////////
// CDice


STDMETHODIMP CDice::RollDice(int* pDice1, int* pDice2)
{
	dice1 = *pDice1 = rand() % 6 + 1;
	dice2 = *pDice2 = rand() % 6 + 1;

	if (dice1 == 6 || dice2 == 6) Fire_SixThrown();
	if (dice1 == dice2) Fire_DoubleThrown();

	return S_OK;
}
