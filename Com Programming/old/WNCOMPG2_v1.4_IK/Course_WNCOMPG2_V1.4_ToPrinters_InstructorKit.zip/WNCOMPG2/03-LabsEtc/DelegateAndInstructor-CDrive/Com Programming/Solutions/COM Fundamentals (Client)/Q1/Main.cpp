////////////////////////////////////////////////////////////
//
//          Test.cpp
//
////////////////////////////////////////////////////////////

#include <windows.h>
#include "Component.h"
#include "Component_i.c"
#include <assert.h>
#include <iostream>
using namespace std;

int main()
{
	// 1. Declare a interface pointer to the object
	HRESULT hr;
	IControl*  pObject = 0;

	// 2. Initialise COM
	hr = CoInitialize(0);
	assert(SUCCEEDED(hr));

	// 3. Create Object
	hr = CoCreateInstance(CLSID_Control, 
												0, 
												CLSCTX_INPROC_SERVER, 
												IID_IControl, 
												(void**)&pObject);
	assert(SUCCEEDED(hr));

	// 4. Call methods
	double average;
	pObject->Average(25.0, 30.0, &average);
	cout << "Average: " << average << endl;

	double product;
	pObject->Multiply(6.5, 4.5, &product);
	cout << "Product: " << product << endl;

	double square;
	pObject->Square(50.0, &square);
	cout << "Square: " << square << endl;

	double squareRoot;
	pObject->SquareRoot(50.0, &squareRoot);
	cout << "Square Root: " << squareRoot << endl;

	// 5. Release pointers
	pObject->Release();

	// 6. Unload COM
	CoUninitialize();
	return 0;
}
