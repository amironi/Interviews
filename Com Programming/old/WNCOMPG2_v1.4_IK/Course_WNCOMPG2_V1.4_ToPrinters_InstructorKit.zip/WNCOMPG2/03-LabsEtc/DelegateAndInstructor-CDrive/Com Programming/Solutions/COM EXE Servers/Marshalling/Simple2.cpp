// Simple2.cpp : Implementation of CSimple2
#include "stdafx.h"
#include "Marshalling.h"
#include "Simple2.h"

/////////////////////////////////////////////////////////////////////////////
// CSimple2


STDMETHODIMP CSimple2::DoubleIt( long *pNumber )
{
	long& number = *pNumber;
	number = 2 * number;
	return S_OK;
}

STDMETHODIMP CSimple2::DisplayMessage( BSTR theMessage )
{
	MessageBoxW(0, theMessage, L"ISimple2", MB_OK);
	return S_OK;
}
