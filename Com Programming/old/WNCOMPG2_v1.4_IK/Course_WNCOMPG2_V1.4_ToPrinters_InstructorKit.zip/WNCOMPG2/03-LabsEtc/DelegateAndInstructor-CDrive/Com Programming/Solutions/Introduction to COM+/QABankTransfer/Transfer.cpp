// Transfer.cpp : Implementation of CTransfer
#include "stdafx.h"
#include "comsvcs.h"
#include "QABankTransfer.h"
#include "Transfer.h"


/////////////////////////////////////////////////////////////////////////////
// CTransfer
#import "..\QABankData\QABankData.tlb"

STDMETHODIMP CTransfer::Transfer(double amount, BSTR fromAccount, BSTR toAccount)
{
	QABANKDATALib::IQABankAccountPtr spQBA;

	short rowsAffected = 0;

	try
	{
		spQBA.CreateInstance( __uuidof( QABANKDATALib::QABankAccount ) );

		// Subtract money from one account, and add it to the other
		if( !spQBA->UpdateAccount( fromAccount, -amount ) || !spQBA->UpdateAccount( toAccount, amount ) )
		{
			_com_issue_errorex( E_FAIL, this, __uuidof( ITransfer ) );
		}
	}
	catch( _com_error ce )
	{
		IObjectContext *pContext = 0;
		CoGetObjectContext( IID_IObjectContext, (void **) &pContext );

		if( pContext )
		{
			if( pContext->IsInTransaction() )
			{
				pContext->SetAbort();
			}

			pContext->Release();
		}
	}

	return S_OK;
}
