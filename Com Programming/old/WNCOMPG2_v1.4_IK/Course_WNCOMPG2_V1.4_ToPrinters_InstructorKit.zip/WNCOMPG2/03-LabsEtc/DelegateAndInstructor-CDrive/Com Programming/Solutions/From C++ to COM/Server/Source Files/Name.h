////////////////////////////////////////////////////////////
//
//      Name.h
//
////////////////////////////////////////////////////////////

#include <string>
using namespace std;

#define interface struct

interface IUnknown
{
	virtual void QueryInterface(const string&, void**) = 0;
	virtual int AddRef() = 0;
	virtual int Release() = 0;
};

interface IConvert : public IUnknown
{
	virtual void ToUpper() = 0;
	virtual void ToLower() = 0;
};

interface IGetSet : public IUnknown
{
	virtual string Get() = 0;
	virtual void Set(const string&) = 0;
	virtual void Print()	= 0;
};

interface IEncodeDecode : public IUnknown
{
	virtual void Encode() = 0;
	virtual void Decode() = 0;
};


extern "C" __declspec(dllexport) void CreateInstance(void**);

