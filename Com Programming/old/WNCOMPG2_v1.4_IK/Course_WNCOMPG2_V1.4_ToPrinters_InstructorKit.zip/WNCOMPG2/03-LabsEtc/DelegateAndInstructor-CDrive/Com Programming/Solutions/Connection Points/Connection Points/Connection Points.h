/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Jan 08 11:55:17 2002
 */
/* Compiler settings for C:\Documents and Settings\dwheeler\My Documents\QA Courses\WNCOMPG2\01-MasterFiles\04-DelegateLabs\Com Programming\Solutions\SOLUTION 12\Connection Points\Connection Points.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Connection_Points_h__
#define __Connection_Points_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDice_FWD_DEFINED__
#define __IDice_FWD_DEFINED__
typedef interface IDice IDice;
#endif 	/* __IDice_FWD_DEFINED__ */


#ifndef ___IDiceEvents_FWD_DEFINED__
#define ___IDiceEvents_FWD_DEFINED__
typedef interface _IDiceEvents _IDiceEvents;
#endif 	/* ___IDiceEvents_FWD_DEFINED__ */


#ifndef __Dice_FWD_DEFINED__
#define __Dice_FWD_DEFINED__

#ifdef __cplusplus
typedef class Dice Dice;
#else
typedef struct Dice Dice;
#endif /* __cplusplus */

#endif 	/* __Dice_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IDice_INTERFACE_DEFINED__
#define __IDice_INTERFACE_DEFINED__

/* interface IDice */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDice;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("76D0E1DF-E93D-11D2-8331-B282CF86C70B")
    IDice : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RollDice( 
            /* [out] */ int __RPC_FAR *pDice1,
            /* [out] */ int __RPC_FAR *pDice2) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDiceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDice __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDice __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDice __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDice __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDice __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDice __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDice __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RollDice )( 
            IDice __RPC_FAR * This,
            /* [out] */ int __RPC_FAR *pDice1,
            /* [out] */ int __RPC_FAR *pDice2);
        
        END_INTERFACE
    } IDiceVtbl;

    interface IDice
    {
        CONST_VTBL struct IDiceVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDice_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDice_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDice_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDice_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDice_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDice_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDice_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDice_RollDice(This,pDice1,pDice2)	\
    (This)->lpVtbl -> RollDice(This,pDice1,pDice2)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDice_RollDice_Proxy( 
    IDice __RPC_FAR * This,
    /* [out] */ int __RPC_FAR *pDice1,
    /* [out] */ int __RPC_FAR *pDice2);


void __RPC_STUB IDice_RollDice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDice_INTERFACE_DEFINED__ */



#ifndef __CONNECTIONPOINTSLib_LIBRARY_DEFINED__
#define __CONNECTIONPOINTSLib_LIBRARY_DEFINED__

/* library CONNECTIONPOINTSLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_CONNECTIONPOINTSLib;

#ifndef ___IDiceEvents_DISPINTERFACE_DEFINED__
#define ___IDiceEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IDiceEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IDiceEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("76D0E1E1-E93D-11D2-8331-B282CF86C70B")
    _IDiceEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IDiceEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IDiceEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IDiceEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IDiceEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IDiceEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IDiceEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IDiceEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IDiceEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IDiceEventsVtbl;

    interface _IDiceEvents
    {
        CONST_VTBL struct _IDiceEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IDiceEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IDiceEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IDiceEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IDiceEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IDiceEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IDiceEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IDiceEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IDiceEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_Dice;

#ifdef __cplusplus

class DECLSPEC_UUID("76D0E1E0-E93D-11D2-8331-B282CF86C70B")
Dice;
#endif
#endif /* __CONNECTIONPOINTSLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
