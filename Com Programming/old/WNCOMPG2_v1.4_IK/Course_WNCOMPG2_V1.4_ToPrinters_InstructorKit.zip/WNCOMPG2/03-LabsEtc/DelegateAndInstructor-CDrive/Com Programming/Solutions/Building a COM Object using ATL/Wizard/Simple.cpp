// Simple.cpp : Implementation of CSimple
#include "stdafx.h"
#include "Wizard.h"
#include "Simple.h"
#include <math.h>

/////////////////////////////////////////////////////////////////////////////
// CSimple


STDMETHODIMP CSimple::SquareRoot(double number, double *pResult)
{
    *pResult = sqrt(number);
	return S_OK;
}

STDMETHODIMP CSimple::Average(double number1, double number2, double *pResult)
{
    *pResult = (number1 + number2) / 2.0;
	return S_OK;
}

STDMETHODIMP CSimple::Multiply(double number1, double number2, double *pResult)
{
    *pResult = number1 * number2;
	return S_OK;
}

STDMETHODIMP CSimple::Square(double number, double *pResult)
{
    *pResult = number * number;
	return S_OK;
}
