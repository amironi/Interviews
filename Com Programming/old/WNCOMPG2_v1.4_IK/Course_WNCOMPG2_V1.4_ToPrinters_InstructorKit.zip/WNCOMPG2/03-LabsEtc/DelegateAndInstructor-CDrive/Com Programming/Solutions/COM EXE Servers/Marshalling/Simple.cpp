// Simple.cpp : Implementation of CSimple
#include "stdafx.h"
#include "Marshalling.h"
#include "Simple.h"

/////////////////////////////////////////////////////////////////////////////
// CSimple


STDMETHODIMP CSimple::DoubleIt(long *pNumber)
{
	long& number = *pNumber;
	number = 2 * number;
	return S_OK;
}

STDMETHODIMP CSimple::DisplayMessage(BSTR theMessage)
{
	MessageBoxW(0, theMessage, L"ISimple", MB_OK);
	return S_OK;
}
