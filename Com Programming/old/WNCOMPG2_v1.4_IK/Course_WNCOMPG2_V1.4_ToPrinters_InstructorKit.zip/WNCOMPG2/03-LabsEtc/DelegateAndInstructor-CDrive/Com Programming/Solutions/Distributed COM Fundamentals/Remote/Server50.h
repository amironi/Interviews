// Server50.h : Declaration of the CServer50

#ifndef __SERVER50_H_
#define __SERVER50_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CServer50
class ATL_NO_VTABLE CServer50 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CServer50, &CLSID_Server50>,
	public IServer50
{
public:
	CServer50()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SERVER50)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CServer50)
	COM_INTERFACE_ENTRY(IServer50)
END_COM_MAP()

// IServer50
public:
	STDMETHOD(Hello)();
};

#endif //__SERVER50_H_
