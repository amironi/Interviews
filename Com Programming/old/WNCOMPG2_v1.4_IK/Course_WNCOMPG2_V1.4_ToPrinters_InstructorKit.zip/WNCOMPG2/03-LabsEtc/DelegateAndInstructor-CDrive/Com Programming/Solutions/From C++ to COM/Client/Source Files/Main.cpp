//////////////////////////////////////////////////////////////////
//
//		Client
//
//////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
using namespace std;

#include "Name.h"


void main()
{
	IUnknown* 		 pUnknown = 0;
	IGetSet*			 pGetSet = 0;
	IEncodeDecode* pEncodeDecode = 0;
	IConvert* 		 pConvert = 0;

// Create object
	CreateInstance(reinterpret_cast<void**>(&pUnknown));

// Invoke methods
	pUnknown->QueryInterface("IGetSet", reinterpret_cast<void**>(&pGetSet));
	pGetSet->Set("THE QUICK BROWN FOX JUMPED OVER THE LAZY DOG"); 

	pUnknown->QueryInterface("IEncodeDecode", reinterpret_cast<void**>(&pEncodeDecode));
	pGetSet->Print();
	pEncodeDecode->Encode();
	pGetSet->Print();
	pEncodeDecode->Decode();
	pGetSet->Print();

	pUnknown->QueryInterface("IConvert", reinterpret_cast<void**>(&pConvert));
	pConvert->ToUpper();
	pGetSet->Print();
	pConvert->ToLower(); 
	pGetSet->Print();

	// Release pointers
	pUnknown->Release();
	pGetSet->Release();
	pConvert->Release();
	pEncodeDecode->Release();
}
