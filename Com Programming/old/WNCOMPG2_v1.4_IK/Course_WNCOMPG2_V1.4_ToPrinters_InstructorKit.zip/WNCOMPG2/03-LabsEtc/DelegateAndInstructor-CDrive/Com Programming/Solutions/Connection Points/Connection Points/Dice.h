// Dice.h : Declaration of the CDice

#ifndef __DICE_H_
#define __DICE_H_

#include "resource.h"       // main symbols
#include "Connection PointsCP.h"

/////////////////////////////////////////////////////////////////////////////
// CDice
class ATL_NO_VTABLE CDice : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDice, &CLSID_Dice>,
	public IConnectionPointContainerImpl<CDice>,
	public IDispatchImpl<IDice, &IID_IDice, &LIBID_CONNECTIONPOINTSLib>,
	public CProxy_IDiceEvents< CDice >
{
public:
	CDice()
	{
	}

	HRESULT FinalConstruct()
	{
		// Seed the random number generator unless you need to
		// debug the code
#ifndef _DEBUG
		srand( GetTickCount() );
#endif
		return S_OK;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DICE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDice)
	COM_INTERFACE_ENTRY(IDice)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CDice)
CONNECTION_POINT_ENTRY(DIID__IDiceEvents)
END_CONNECTION_POINT_MAP()


// IDice
public:
	STDMETHOD(RollDice)(int* pDice1, int* pDice2);
private:
	int dice1;
	int dice2;
};

#endif //__DICE_H_
