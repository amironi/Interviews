// Server.cpp : Implementation of CServer
#include "stdafx.h"
#include "Errors.h"
#include "Server.h"
#include <math.h>

/////////////////////////////////////////////////////////////////////////////
// CServer

STDMETHODIMP CServer::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IServer
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CServer::SquareRoot(double number, double *pResult)
{
	HRESULT hr = S_OK;

	if( number < 0.0 )
	{
		hr = Error( L"You can't take the square root of a negative number", 
								__uuidof(IServer), 
								E_FAIL );
	}
	else
	{
		*pResult = sqrt( number );
	}

	return hr;
}
