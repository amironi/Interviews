
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0280 */
/* at Fri Feb 01 19:03:36 2002
 */
/* Compiler settings for C:\Documents and Settings\dwheeler\My Documents\QA Courses\WNCOMPG2\01-MasterFiles\04-DelegateLabs\Com Programming\Solutions\Distributed COM Fundamentals\Remote\Remote.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Remote_h__
#define __Remote_h__

/* Forward Declarations */ 

#ifndef __IServer50_FWD_DEFINED__
#define __IServer50_FWD_DEFINED__
typedef interface IServer50 IServer50;
#endif 	/* __IServer50_FWD_DEFINED__ */


#ifndef __Server50_FWD_DEFINED__
#define __Server50_FWD_DEFINED__

#ifdef __cplusplus
typedef class Server50 Server50;
#else
typedef struct Server50 Server50;
#endif /* __cplusplus */

#endif 	/* __Server50_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IServer50_INTERFACE_DEFINED__
#define __IServer50_INTERFACE_DEFINED__

/* interface IServer50 */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IServer50;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("85D93F0A-9B65-424E-A34E-E91C2F9AE7B1")
    IServer50 : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Hello( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IServer50Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IServer50 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IServer50 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IServer50 __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Hello )( 
            IServer50 __RPC_FAR * This);
        
        END_INTERFACE
    } IServer50Vtbl;

    interface IServer50
    {
        CONST_VTBL struct IServer50Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IServer50_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IServer50_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IServer50_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IServer50_Hello(This)	\
    (This)->lpVtbl -> Hello(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IServer50_Hello_Proxy( 
    IServer50 __RPC_FAR * This);


void __RPC_STUB IServer50_Hello_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IServer50_INTERFACE_DEFINED__ */



#ifndef __REMOTELib_LIBRARY_DEFINED__
#define __REMOTELib_LIBRARY_DEFINED__

/* library REMOTELib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_REMOTELib;

EXTERN_C const CLSID CLSID_Server50;

#ifdef __cplusplus

class DECLSPEC_UUID("CF2645B5-C493-4003-80FB-B2C6D9556C14")
Server50;
#endif
#endif /* __REMOTELib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


