// TestRemote.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#define _WIN32_DCOM

#include <windows.h>
#include <assert.h>

#import "..\Remote\Remote.tlb"
using namespace REMOTELib;

int main()
{
	CoInitialize( 0 );
	IServer50Ptr spIServer50 = 0;

	
	COSERVERINFO csi = { 0 };

	//
	// Establish the interface(s) were after
	//
	MULTI_QI mqi = { 0 };
	mqi.pIID = &(__uuidof( IServer50 ) );

	csi.pwszName = L"WNCOMPG0"; // Your name here
	
	HRESULT hr;
	hr = CoCreateInstanceEx( __uuidof(Server50),
												   0,
												   CLSCTX_REMOTE_SERVER,
												   &csi,
												   1,
													 &mqi 
												 );
	
	assert(SUCCEEDED(hr));

	// Take control of the interface
	spIServer50.Attach( (IServer50 *) mqi.pItf, false );

	spIServer50->Hello();
	spIServer50 = 0; 

	CoUninitialize();
	return 0;
}