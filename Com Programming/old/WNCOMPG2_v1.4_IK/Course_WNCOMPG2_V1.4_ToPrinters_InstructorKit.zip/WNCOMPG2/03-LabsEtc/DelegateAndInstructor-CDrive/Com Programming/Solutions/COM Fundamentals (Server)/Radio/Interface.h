////////////////////////////////////////////////////////////
//
//          Interface.h
//
////////////////////////////////////////////////////////////

#pragma once
#include <windows.h>

// spot (and correct!) the deliberate mistake on the line below
class ITrafficInfo : public IUnknown
{
public:
    virtual HRESULT __stdcall Alert( char* message ) = 0;
};


// Definitions of GUIDs

// IID_IClassFactory is defined by Microsoft
// IID_IUnknown is defined by Microsoft
// CLSID_Car is the class id of the COM object
// IID_ITrafficInfo is the interface id of ITrafficInfo


extern "C"
{


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// 
// CREATE TWO NEW GUIDs USING GUIDGEN (Option 3)
// THE TWO NEW GUIDS SHOULD HAVE THE SYMBOLIC NAMES
// CLSID_Radio AND IID_ITrafficInfo, AS THESE NAMES ARE
// USED THROUGHOUT THE TEST CLIENT
// 
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  
  

	// {23124BBA-D255-40fb-9006-5F1AA456B4F0}
	const GUID CLSID_Radio = 
	{ 0x23124bba, 0xd255, 0x40fb, { 0x90, 0x6, 0x5f, 0x1a, 0xa4, 0x56, 0xb4, 0xf0 } };

	// {DA518D9C-D87E-4ca0-A6B7-92C84FA3FC62}
	const GUID IID_ITrafficInfo = 
	{ 0xda518d9c, 0xd87e, 0x4ca0, { 0xa6, 0xb7, 0x92, 0xc8, 0x4f, 0xa3, 0xfc, 0x62 } };

}

