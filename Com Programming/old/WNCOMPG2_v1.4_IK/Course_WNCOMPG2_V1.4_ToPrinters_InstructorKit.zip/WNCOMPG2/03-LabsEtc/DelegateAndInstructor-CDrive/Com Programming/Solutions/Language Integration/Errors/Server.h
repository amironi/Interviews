// Server.h : Declaration of the CServer

#ifndef __SERVER_H_
#define __SERVER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CServer
class ATL_NO_VTABLE CServer : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CServer, &CLSID_Server>,
	public ISupportErrorInfo,
	public IDispatchImpl<IServer, &IID_IServer, &LIBID_ERRORSLib>
{
public:
	CServer()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SERVER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CServer)
	COM_INTERFACE_ENTRY(IServer)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IServer
public:
	STDMETHOD(SquareRoot)(/*[in]*/ double number, /*[out, retval]*/ double* pResult);
};

#endif //__SERVER_H_
