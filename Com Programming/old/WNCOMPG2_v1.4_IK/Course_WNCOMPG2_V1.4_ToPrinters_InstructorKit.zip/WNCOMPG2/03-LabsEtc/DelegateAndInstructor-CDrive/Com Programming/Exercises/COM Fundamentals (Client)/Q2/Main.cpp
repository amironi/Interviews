////////////////////////////////////////////////////////////
//
//          Test.cpp
//
////////////////////////////////////////////////////////////

#include <windows.h>
#include "Component.h"
#include "Component_i.c"
#include <assert.h>

int main()
{
	// 1. Declare interface pointers

	// 2. Initialise COM

	// 3. Create Class Factory

	// 4. Create two COM object from the class factory using CreateInstance()

	// 5. Call 2 methods on one object and the other 2 methods on the second object

	// 6. Release all pointers

	// 7. Unload COM

	return 0;
}
