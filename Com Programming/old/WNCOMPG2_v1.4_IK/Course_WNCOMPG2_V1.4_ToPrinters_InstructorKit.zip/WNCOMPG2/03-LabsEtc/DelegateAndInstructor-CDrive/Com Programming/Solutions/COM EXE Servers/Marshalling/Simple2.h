// Simple2.h : Declaration of the CSimple2

#ifndef __SIMPLE2_H_
#define __SIMPLE2_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimple2
class ATL_NO_VTABLE CSimple2 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSimple2, &CLSID_Simple2>,
	public ISimple2
{
public:
	CSimple2()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLE2)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSimple2)
	COM_INTERFACE_ENTRY(ISimple2)
END_COM_MAP()

// ISimple2
public:
	STDMETHOD(DisplayMessage)(/*[in]*/ BSTR theMessage);
	STDMETHOD(DoubleIt)(/*[in,out]*/ long* pNumber);
};

#endif //__SIMPLE2_H_
