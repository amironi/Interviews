#include <iostream>
#include <string>
using namespace std;

#include "Name.h"


int main()
{
// TODO 1
// Declare interface pointers to:
//		IUnknown*
//		IGetSet*
//		IEncodeDecode*
//		IConvert*

// TODO 2
// Use CreateInstance to create a server instance and return
// and IUnknown* pointer

// TODO 3
// Use QueryInterface to get an IGetSet* pointer

// TODO 4
// Call the Set() method.

// TODO 5
// Use QueryInterface() to get an IEncodeDecode* pointer

// TODO 6
// Call the Print() (on the IGetSet interface), Encode() and Decode() methods

// TODO 7
// Use QueryInterface() to get an IConvert* pointer

// TODO 8
// Call the ToUpper(), Print(), ToLower() and Print() methods

// TODO 9
// Release all 4 interface pointers

	return 0;
}
