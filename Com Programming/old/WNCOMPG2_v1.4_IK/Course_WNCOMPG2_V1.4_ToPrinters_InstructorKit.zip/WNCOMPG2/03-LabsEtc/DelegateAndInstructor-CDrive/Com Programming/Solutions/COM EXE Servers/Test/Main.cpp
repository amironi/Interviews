////////////////////////////////////////////////////////////
//
//		Main.cpp
//
////////////////////////////////////////////////////////////

#include <windows.h>
#include <assert.h>
#import "..\Marshalling\Marshalling.tlb"
#include <iostream>
using namespace std;
using namespace MARSHALLINGLib;

void UniversalMarshalling()
{
	// 1. Declare a interface pointer to the object
	HRESULT hr;
	ISimple*	pISimple = 0;

	// 2. Initialise COM
	hr = CoInitialize( 0 );
	assert( SUCCEEDED( hr ) );

	// 3. Create Object
	hr = CoCreateInstance( __uuidof(Simple), 
												 0, 
												 CLSCTX_LOCAL_SERVER, 
												 __uuidof(ISimple), 
												 (void**) &pISimple );
	assert( SUCCEEDED( hr ) );

	// 4. Call methods
	BSTR hello = SysAllocString( L"Hello" );
	pISimple->DisplayMessage( hello );
	SysFreeString( hello );

	long x = 100;
	pISimple->DoubleIt(&x);
	cout << "x = " << x << endl;
	 
	// 5. Release pointers
	pISimple->Release();

	// 6. Unload COM
	CoUninitialize();
}

void MIDL_Marshalling()
{
	// 1. Declare a interface pointer to the object
	HRESULT hr;
	ISimple2*  pISimple2 = 0;

	// 2. Initialise COM
	hr = CoInitialize( 0 );
	assert( SUCCEEDED( hr ) );

	// 3. Create Object
	hr = CoCreateInstance( __uuidof(Simple2), 
												 0, 
												 CLSCTX_LOCAL_SERVER, 
												 __uuidof(ISimple2), 
												 (void**) &pISimple2 );
	assert(SUCCEEDED(hr));

	// 4. Call methods
	BSTR hello = SysAllocString( L"Hello" );
	pISimple2->DisplayMessage( hello );
	SysFreeString( hello );

	long x = 100;
	pISimple2->DoubleIt( &x );
	cout << "x = " << x << endl;
	 
	// 5. Release pointers
	pISimple2->Release();

	// 6. Unload COM
	CoUninitialize();
}


int main()
{
	UniversalMarshalling();
	MIDL_Marshalling();
	return 0;
}