// DataTypes.h: Definition of the DataTypes class
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATYPES_H__6F96ED56_FDA2_11D2_8368_204C4F4F5020__INCLUDED_)
#define AFX_DATATYPES_H__6F96ED56_FDA2_11D2_8368_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// DataTypes

class DataTypes : 
	public IDispatchImpl<ISafeArray, &IID_ISafeArray, &LIBID_DATATYPESLib>, 
	public IDispatchImpl<IVariant, &IID_IVariant, &LIBID_DATATYPESLib>, 
	public IDispatchImpl<IBSTR, &IID_IBSTR, &LIBID_DATATYPESLib>, 
	public ISupportErrorInfo,
	public CComObjectRoot,
	public CComCoClass<DataTypes,&CLSID_DataTypes>
{
public:
	STDMETHOD(ToLower)(/*[in,out]*/ BSTR* pString);
	STDMETHOD(ToUpper)(/*[in, out]*/ BSTR* pString);
	DataTypes() {}
BEGIN_COM_MAP(DataTypes)
	COM_INTERFACE_ENTRY2(IDispatch, ISafeArray)
	COM_INTERFACE_ENTRY(ISafeArray)
	COM_INTERFACE_ENTRY(IVariant)
	COM_INTERFACE_ENTRY(IBSTR)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
DECLARE_NOT_AGGREGATABLE(DataTypes) 

DECLARE_REGISTRY_RESOURCEID(IDR_DataTypes)
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISafeArray
	STDMETHOD(CreateArray)(SAFEARRAY** ppArray);
	STDMETHOD(DoubleArray)(SAFEARRAY** ppArray);
    STDMETHOD(SumTheArray)(SAFEARRAY** ppArray, long* pTotal);

// IVariant
	STDMETHOD(ExpandRectangle)(/*[in,out]*/ VARIANT* pRectangle);

// IBSTR
};

#endif // !defined(AFX_DATATYPES_H__6F96ED56_FDA2_11D2_8368_204C4F4F5020__INCLUDED_)
