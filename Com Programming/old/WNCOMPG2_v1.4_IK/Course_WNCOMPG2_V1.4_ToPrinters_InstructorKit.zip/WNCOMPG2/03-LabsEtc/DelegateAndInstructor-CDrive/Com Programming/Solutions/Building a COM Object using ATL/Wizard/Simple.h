// Simple.h : Declaration of the CSimple

#ifndef __SIMPLE_H_
#define __SIMPLE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimple
class ATL_NO_VTABLE CSimple : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSimple, &CLSID_Simple>,
	public IDispatchImpl<ISimple, &IID_ISimple, &LIBID_WIZARDLib>
{
public:
	CSimple()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSimple)
	COM_INTERFACE_ENTRY(ISimple)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ISimple
public:
	STDMETHOD(Square)(/*[in]*/ double number, /*[out, retval]*/ double* pResult);
	STDMETHOD(Multiply)(/*[in]*/ double number1, /*[in]*/ double number2, /*[out, retval]*/ double* pResult);
	STDMETHOD(Average)(/*[in]*/ double number1, /*[in]*/ double number2, /*[out, retval]*/ double* pResult);
	STDMETHOD(SquareRoot)(/*[in]*/ double number, /*[out, retval]*/ double* pResult);
};

#endif //__SIMPLE_H_
