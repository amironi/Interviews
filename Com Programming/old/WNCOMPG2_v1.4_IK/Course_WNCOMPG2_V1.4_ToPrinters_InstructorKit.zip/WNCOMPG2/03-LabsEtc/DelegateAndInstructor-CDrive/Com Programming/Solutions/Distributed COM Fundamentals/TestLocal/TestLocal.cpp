// TestLocal.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <assert.h>

#import "..\Remote\Remote.tlb"
using namespace REMOTELib;

int main()
{
	CoInitialize( 0 );
	IServer50Ptr spIServer50 = 0;

	HRESULT hr;
	hr = CoCreateInstance( __uuidof(Server50),
												 0,
												 CLSCTX_LOCAL_SERVER,
												 __uuidof(IServer50),
												 (void**) &spIServer50
											 );
	
	assert(SUCCEEDED(hr));

	spIServer50->Hello();
	spIServer50 = 0; 

	CoUninitialize();
	return 0;
}
