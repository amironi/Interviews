// Simple.h : Declaration of the CSimple

#ifndef __SIMPLE_H_
#define __SIMPLE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimple
class ATL_NO_VTABLE CSimple : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSimple, &CLSID_Simple>,
	public IDispatchImpl<ISimple, &IID_ISimple, &LIBID_MARSHALLINGLib>
{
public:
	CSimple()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSimple)
	COM_INTERFACE_ENTRY(ISimple)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ISimple
public:
	STDMETHOD(DisplayMessage)(/*[in]*/ BSTR theMessage);
	STDMETHOD(DoubleIt)(/*[in,out]*/ long* pNumber);
};

#endif //__SIMPLE_H_
