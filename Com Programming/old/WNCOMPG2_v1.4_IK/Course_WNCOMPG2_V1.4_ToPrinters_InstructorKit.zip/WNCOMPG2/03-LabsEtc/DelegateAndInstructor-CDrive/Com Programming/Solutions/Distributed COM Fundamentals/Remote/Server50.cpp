// Server50.cpp : Implementation of CServer50
#include "stdafx.h"
#include "Remote.h"
#include "Server50.h"

/////////////////////////////////////////////////////////////////////////////
// CServer50


STDMETHODIMP CServer50::Hello()
{
	MessageBoxW( 0, L"Hello DCOM", L"Server50", MB_OK );

	return S_OK;
}
