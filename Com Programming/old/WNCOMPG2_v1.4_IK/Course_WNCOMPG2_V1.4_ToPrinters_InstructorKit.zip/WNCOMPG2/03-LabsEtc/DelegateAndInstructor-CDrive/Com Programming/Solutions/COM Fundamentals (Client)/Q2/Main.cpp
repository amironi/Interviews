////////////////////////////////////////////////////////////
//
//          Test.cpp
//
////////////////////////////////////////////////////////////

#include <windows.h>
#include "Component.h"
#include "Component_i.c"
#include <assert.h>

int main()
{
	// 1. Declare interface pointers
	HRESULT hr = S_OK;
	IControl*  pObject1 = 0;
	IControl*  pObject2 = 0;
	IClassFactory* pClassFactory = 0;

	// 2. Initialise COM
	hr = CoInitialize(0);
	assert(SUCCEEDED(hr));

	// 3. Create Class Factory
	hr = CoGetClassObject(CLSID_Control, 
												CLSCTX_INPROC, 
												0,
												IID_IClassFactory, 
												(void**)&pClassFactory);
	assert(SUCCEEDED(hr));

	// 4. Create Objects
	hr = pClassFactory->CreateInstance(0, 
																		 IID_IControl, 
																		 (void**)&pObject1);
	assert(SUCCEEDED(hr));

	hr = pClassFactory->CreateInstance(0, 
																		 IID_IControl, 
																		 (void**)&pObject2);
	assert(SUCCEEDED(hr));

	// 5. Call methods
	double average;
	pObject1->Average(25.0, 30.0, &average);

	double result;
	pObject2->Multiply(6.5, 4.5, &result);

	double square;
	pObject1->Square(50.0, &square);

	double squareRoot;
	pObject2->SquareRoot(50.0, &squareRoot);

	// 6. Release pointers
	pClassFactory->Release();
	pObject1->Release();
	pObject2->Release();

	// 7. Unload COM
	CoUninitialize();
	return 0;
}
