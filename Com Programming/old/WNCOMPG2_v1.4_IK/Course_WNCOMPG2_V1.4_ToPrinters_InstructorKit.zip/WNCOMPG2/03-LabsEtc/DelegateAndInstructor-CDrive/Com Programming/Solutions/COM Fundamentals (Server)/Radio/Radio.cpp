////////////////////////////////////////////////////////////
//
//	    Radio.cpp
//
////////////////////////////////////////////////////////////
#include "Radio.h"

// N.B. Look in Interface.h for definitions of GUIDS
// change all return codes - they have been added to get a clean compile
LONG Radio::objectCount = 0;

Radio::Radio()
  : refCount( 0 )
{
  // There is now one more object in the world, so
  // increment the object count
	
	InterlockedIncrement( &objectCount );

}

Radio::~Radio()
{
  // There is now one less object in the world, so
  // decrement the object count

	InterlockedDecrement( &objectCount );

}

bool Radio::DoObjectsExist()
{

	// Use the value of objectCount to determine whether any
	// instances of the Radio class exist. If there are no objects,
	// return false, otherwise return true.
	bool bReply = true;
	
	if( 0 == objectCount )
		bReply = false;

	return bReply;
}

HRESULT __stdcall Radio::QueryInterface( REFIID id, void** ppv )
{
    // Accept IUnknown and ITrafficInfo (return S_OK)
    // Reject all other intefaces (return E_NOINTERFACE)

    // If the client requests a valid interface you must AddRef the object.
    HRESULT hr = S_OK;
		if( !ppv )
			return E_POINTER;

		*ppv = 0;

		if( IID_IUnknown == id || IID_ITrafficInfo == id )
		{
			*ppv = static_cast< ITrafficInfo * >( this );
		}
		else
		{
			hr = E_NOINTERFACE;
		}
	
		if( SUCCEEDED( hr ) )
		{
			reinterpret_cast< IUnknown * >( *ppv )->AddRef();
		}

    return hr;
}

ULONG __stdcall Radio::AddRef()
{
    refCount++;

    return 0;
}

ULONG __stdcall Radio::Release()
{
    // Decrement reference count and 'commit suicide' if the count is zero.
		ULONG temp = --refCount;
		if( !refCount )
		{
			delete this;
		}

    return temp;
}

HRESULT __stdcall Radio::Alert( char* message )
{
    MessageBoxA( 0, message, "Radio Server", MB_ICONINFORMATION );

    return S_OK;
}

