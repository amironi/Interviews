All .doc files in this folder will be collated to form the Index keywords.
The format should be in a 2 column table :-

|State Pattern	|	|

If you want a 2-level index - eg the above to appear as
Patterns
..State

then modify the above to be

|State Pattern	|Patterns:#State |

It is because Word has some serious shortcomings when collating documents that the
above format is used ( Word would use Patterns:State )

If you want an index keyword beginning with # (eg #Define), make sure that you have a 2-level index
item associated with it :-
|#Define	|PreProcessor:##Define|



If you want to discretely select a word (eg the keyword "As") and don't want every occurence :-
  In a Word doc, use the regular Word marking - highlight the word, ALT + Shift + X.
  If you want to see that its caught it, then Tools Menu/Options/View and check Field Codes

  In a Powerpoint, create a textbox outside the visible area and enter {{{As}}}
