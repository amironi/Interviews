The files in this folder have several uses :-

Spell Check
===========
The easiest way to do a Spell Check is to select Spell Check and let it run through to completion.
Then go into each History/Bookx/Spelling.doc and delete the words which are clearly mis-spellings
or any any way suspect. Save the file (which now contains known good words).

Collate the various good Spellings.doc's from the various folders into 1 doc
dict-<coursename>.doc in 01-Masters\11-Dictionary.

Run the Spell Check again.
You will now have a ReducedConcatFile in which all the suspect words & mis-spellings are highlighted.
Locate these in the original .ppt, .doc and correct them.
Any good words, add to dict-<coursename>.doc


Search for symbols/words in course
==================================
This is useful if you are converting a course from one language to another and want to ensure
that you have picked up all occurences of eg the keywords unique to the original language.
Produce a file named "AlsoSearchFor.txt" in the 08-History folder.
In it place all the symbols, phrases you want to search for in the course (1 per line)
Run the spell check.
The ReducedConcatFile will contain all such words highlighted.
An example is stored in ManualFixes.

Version Differencing
====================
You can see the non-formatting changes in a course by comparing Version 'n' to version 'n-1'
You can do this easily from the CommandCenter/Previous Versions button.
