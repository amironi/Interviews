#include "../include/interpreter.h"
#include <iostream>


uint32_t getOperand(Operand operand, uint32_t* registers){

    uint32_t v = operand.value;
    
    if( operand.type == Register ) 
        v = registers[v];
    return v;
}

struct ExecuteMov : IExecute{
    void run(Instruction* instruction, Memory *memory, uint32_t* registers )
    {
        registers[instruction->getOperand(0).value] = 
            getOperand(instruction->getOperand(1), registers);
    }
};

struct ExecuteLdr : IExecute{
    void run(Instruction* instruction, Memory *memory, uint32_t* registers )
    {
        registers[instruction->getOperand(0).value] = 
            memory->get(getOperand(instruction->getOperand(1), registers));
    }
};

struct ExecuteStr : IExecute{
    void run(Instruction* instruction, Memory *memory, uint32_t* registers )
    {
        memory->set(
            getOperand(instruction->getOperand(1), registers), 
            registers[instruction->getOperand(0).value]);
    }
};

struct ExecuteB : IExecute{
    void run(Instruction* instruction, Memory *memory, uint32_t* registers )
    {
        registers[15] = getOperand(instruction->getOperand(0), registers);
    }
};


struct ExecuteBcon : IExecute{
    void run(Instruction* instruction, Memory *memory, uint32_t* registers )
    {
        if( getOperand(instruction->getOperand(0), registers)  == 1 )
            registers[15] = getOperand(instruction->getOperand(1), registers);
    }
};

struct ExecuteGTE : IExecute{
    void run(Instruction* instruction, Memory *memory, uint32_t* registers )
    {
        registers[instruction->getOperand(0).value] = 
            getOperand(instruction->getOperand(1), registers) >=
            getOperand(instruction->getOperand(2), registers);
    }
};

struct ExecuteAdd : IExecute{
    void run(Instruction* instruction, Memory *memory, uint32_t* registers )
    {
        registers[instruction->getOperand(0).value] = 
            getOperand(instruction->getOperand(1), registers) + 
            getOperand(instruction->getOperand(2), registers);
    }
};


void Interpreter::runProgram(Program *prog, Memory *memory)
{

    _executeMap[MOV] = shared_ptr<IExecute>(new ExecuteMov());
    _executeMap[LDR] = shared_ptr<IExecute>(new ExecuteLdr());
    _executeMap[STR] = shared_ptr<IExecute>(new ExecuteStr());
    _executeMap[B] = shared_ptr<IExecute>(new ExecuteB());
    _executeMap[BCond] = shared_ptr<IExecute>(new ExecuteBcon());
    _executeMap[GTE] = shared_ptr<IExecute>(new ExecuteGTE());
    _executeMap[ADD] = shared_ptr<IExecute>(new ExecuteAdd());

    _registers[15] = 0;

    while(false == prog->isLastInstruction(_registers[15]))
    {
        Instruction* instruction = prog->getInstruction(_registers[15]++);

        _executeMap[instruction->type()]->run( instruction, memory, _registers);
   }
    
}