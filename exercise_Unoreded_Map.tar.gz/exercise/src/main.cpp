#include "../include/program.h"
#include "../include/memory.h"
#include "../include/interpreter.h"

#include <iostream>
#include <ctime>

int main()
{
	Program prog;
	Memory mem;
	Interpreter interpreter;
	
	std::srand(std::time(0));
	uint32_t min = 0;

	for (int i = 0; i < 400; i += 4)
	{
		uint32_t num = std::rand() % 100000;

		if ((min == 0) || (num < min))
		{
			min = num;
		}

		mem.set(0x1000 + i, num);
	}

	interpreter.runProgram(&prog, &mem);

	if (mem.get(0x0) == min)
	{
		std::cout << "Yey you did it! Guess what the app does?" << std::endl;
	}
	else
	{
		std::cout << "Please try again..." << std::endl;
	}
	
	return 0;
}