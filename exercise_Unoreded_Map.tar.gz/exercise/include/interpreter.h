#pragma once

#include "program.h"
#include "memory.h"
#include "instruction.h"
#include <unordered_map>
#include <memory>


using namespace std;


struct IExecute
{
    virtual void run(Instruction* instruction, Memory *memory, uint32_t* registers ) = 0;
};

class Interpreter
{
	uint32_t _registers[16];
	unordered_map<int, shared_ptr<IExecute>> _executeMap; 

public:
	void runProgram(Program *program, Memory *memory);
};