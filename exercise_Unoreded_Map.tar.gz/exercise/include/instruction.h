#pragma once

#include <string.h>
#include <stdint.h>
#include <vector>

enum OperandType
{
	Register = 0,
	Immediate
};

struct Operand
{
	OperandType type;
	uint32_t value;
};

enum InstructionType
{
	MOV = 0,
	LDR,
	STR,
	B,
	BCond,
	GTE,
	ADD
};

class Instruction
{
private:
	InstructionType _type;
	std::vector<Operand> _operands;
public:
	Instruction(InstructionType type);
	InstructionType type();
	uint32_t numOfOperands();
	Operand getOperand(uint32_t index); //index of operand from instruction
	void addOperand(Operand operand);

};